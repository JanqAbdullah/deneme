package com.example.proje_adi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
